﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeLibrary
{
    
    public class Class1
    {
        public SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-U9I41QJ\SQLEXPRESS; Trusted_Connection = Yes; DataBase = uvilirni_dom;");
        public DataTable OverallSelect(string selectSQL) // функция подключения к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase"); // создаём таблицу в приложении
            sqlConnection.Open(); // открываем базу данных
            SqlCommand sqlCommand = sqlConnection.CreateCommand(); // создаём команду
            sqlCommand.CommandText = selectSQL; // присваиваем команде текст
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand); // создаём обработчик
            sqlDataAdapter.Fill(dataTable); // возращаем таблицу с результатом
            sqlConnection.Close();
            return dataTable;
        }
        public bool adding_deleting_changing(string selectSQL) // функция подключения к базе данных и обработка запросов
        {
            DataTable dataTable = new DataTable("dataBase"); // создаём таблицу в приложении
            sqlConnection.Open(); // открываем базу данных
            SqlCommand sqlCommand = sqlConnection.CreateCommand(); // создаём команду
            sqlCommand.CommandText = selectSQL; // присваиваем команде текст
            try
            {
                sqlCommand.ExecuteNonQuery();
            }
            catch
            {
                sqlConnection.Close();
                return false;
            }
            sqlConnection.Close();
            return true;
        }
    }
}
