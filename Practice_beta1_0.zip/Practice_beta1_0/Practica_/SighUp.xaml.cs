﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PracticeLibrary;

namespace Practica_
{
    /// <summary>
    /// Логика взаимодействия для SighUp.xaml
    /// </summary>
    public partial class SighUp : Page
    {
        public MainWindow _mainWindow;
        public SighUp(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
        }

        private void labeltologin_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            _mainWindow.OpenPage(MainWindow.pages.login, _mainWindow.mainframe);
        }

        private void buttonregister_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text.Length > 0) // проверяем логин
            {
                Class1 funcs = new Class1();
                string cmd;
                bool registerallowed = true;
                DataTable dt_user = funcs.OverallSelect("SELECT * FROM [dbo].[Users]");
                for (int i = 0; i < dt_user.Rows.Count; i++)
                {
                    if (dt_user.Rows[i][1].ToString() == login.Text)
                    {
                        registerallowed = false;
                        MessageBox.Show("this username is already taken!");
                        return;
                    }
                }
                if (registerallowed)
                {
                    cmd = "INSERT INTO [dbo].[Users] (Login, Password, Role) VALUES ('" + login.Text + "', '" + pass.Text +"', 2)";
                    try
                    {
                        funcs.OverallSelect(cmd);
                        MessageBox.Show("Successful");
                    }
                    catch
                    {
                        MessageBox.Show("Mistake!");
                    }
                    
                    _mainWindow.OpenPage(MainWindow.pages.login, _mainWindow.mainframe);
                }


            }
            else { MessageBox.Show("Укажите логин"); }
        }
    }
}
