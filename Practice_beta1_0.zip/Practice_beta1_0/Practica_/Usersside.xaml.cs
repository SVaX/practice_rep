﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PracticeLibrary;

namespace Practica_
{
    /// <summary>
    /// Логика взаимодействия для Usersside.xaml
    /// </summary>
    public partial class Usersside : Page
    {
        DataTable dt_products;
        UserWindow uswindow;
        Class1 funcs = new Class1();
        public Usersside(UserWindow _userWindow)
        {
            InitializeComponent();
            uswindow = _userWindow;
            dt_products = funcs.OverallSelect("SELECT name_product AS Название FROM [dbo].[Products]");
            itemsgrid.ItemsSource = dt_products.DefaultView;
        }

        private void ToCartButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataTable dt_user = funcs.OverallSelect("SELECT id FROM [dbo].[Products] WHERE name_product='" + nametext.Text + "'");
                int id_user = uswindow.id_ofuser;
                string cmd = "INSERT INTO [dbo].[Cart] (id_user, id_product) VALUES (" + id_user + ", " + dt_user.Rows[0][0] + ")";
                bool success = funcs.adding_deleting_changing(cmd);
                if (success)
                {
                    MessageBox.Show("Successfully added!");
                }
                else
                {
                    MessageBox.Show("Looks like something's gone wrong");
                    return;
                }
            }
            catch
            {
                MessageBox.Show("Ooops, something went wrong?");
                return;
            }
        }

        private void itemsgrid_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            DataRowView drv = itemsgrid.SelectedItem as DataRowView;
            nametext.Text = drv[0].ToString();
            dt_products = funcs.OverallSelect("SELECT price FROM [dbo].[Products] WHERE name_product = '" + drv[0].ToString() + "'");
            for (int i = 0; i < dt_products.Rows.Count; i++)
            {
                pricetext.Text = dt_products.Rows[0][0].ToString();
            }
            dt_products = funcs.OverallSelect("SELECT description FROM [dbo].[Products] WHERE name_product = '" + drv[0].ToString() + "'");
            for (int i = 0; i < dt_products.Rows.Count; i++)
            {
                descriptiontext.Text = dt_products.Rows[0][0].ToString();
            }
        }

        private void ToCartGoing_Click(object sender, RoutedEventArgs e)
        {
            uswindow.OpenPage(UserWindow.pages.icart, uswindow.listforeverybody);
        }
    }
}
