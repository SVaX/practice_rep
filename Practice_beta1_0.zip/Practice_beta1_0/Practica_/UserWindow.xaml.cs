﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practica_
{
    /// <summary>
    /// Логика взаимодействия для AdminWindow.xaml
    /// </summary>
    public partial class UserWindow : Window
    {
        MainWindow mainwindow;
        public int id_ofuser;
        public enum pages
        {
            icart,
            adminside,
            useside
        }
        public void OpenPage(pages page, Frame frame)
        {
           if (page == pages.adminside)
            {
                frame.Navigate(new Adminsside(mainwindow));
            }
            else if (page == pages.useside)
            {
                frame.Navigate(new Usersside(this));
            }
           else if(page == pages.icart)
            {
                frame.Navigate(new Cart(this));
            }
        }
        public UserWindow(string nameofsecondframe, int idofuser)
        {
            InitializeComponent();
            id_ofuser = idofuser;
            if (nameofsecondframe == "adminsframe")
            {
                OpenPage(pages.adminside, listforeverybody);
            }
            else if (nameofsecondframe == "usersframe")
            {
                OpenPage(pages.useside, listforeverybody);
            }
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
