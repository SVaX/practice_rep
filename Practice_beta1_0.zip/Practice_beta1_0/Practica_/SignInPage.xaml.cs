﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PracticeLibrary;

namespace Practica_
{
    /// <summary>
    /// Логика взаимодействия для SignInPage.xaml
    /// </summary>
    public partial class SignInPage : Page
    {
        Class1 funcs = new Class1();
        public MainWindow _mainWindow;
        public SignInPage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
        }

        private void buttonlogin_Click(object sender, RoutedEventArgs e)
        {
            if(textboxlogin.Text.Length != 0)
            {
                if(textboxpass.Text.Length != 0)
                {
                    DataTable dt_users = funcs.OverallSelect("SELECT * FROM [dbo].[Users] WHERE [Login] = '" + textboxlogin.Text + "' AND [Password] = '" + textboxpass.Text + "'");
                    if (dt_users.Rows.Count > 0) // если такая запись существует
                    {
                        int b = dt_users.Columns.IndexOf("role");
                        DataRow a = dt_users.Rows[0];
                        if (a[b].Equals(1))
                        {
                            dt_users = funcs.OverallSelect("SELECT id FROM [dbo].[Users] WHERE [Login] = '" + textboxlogin.Text + "'");
                            UserWindow uswindow = new UserWindow("adminsframe", int.Parse(dt_users.Rows[0][0].ToString()));
                            uswindow.Show();
                            _mainWindow.Close();
                        }
                        if (a[b].Equals(2))
                        {

                            UserWindow uswindow = new UserWindow("usersframe", int.Parse(dt_users.Rows[0][0].ToString()));
                            uswindow.Show();
                            _mainWindow.Close();
                        }
                    }
                }
            }
        }

        private void Label_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            _mainWindow.OpenPage(MainWindow.pages.register, _mainWindow.mainframe);
        }
    }
}
